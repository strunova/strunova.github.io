# STRUNOVA Terms of Use

These terms apply to the STRUNOVA application (“the app”) in its alpha versions, downloaded from https://strunova.github.io.

Copyright © 2026 themasterofbuttons. All rights reserved.

## 1. Permission to use

You may download, install and use the app free of charge, for personal and non-commercial purposes, on computers that you own or control.

## 2. What you may not do

Without written permission from the author, you may not:

- sell, rent, lend, redistribute or publish the app, in whole or in part;
- modify the app, or decompile, disassemble or reverse engineer it, except where the law expressly allows it;
- remove or change any copyright or license notice.

## 3. Alpha version

This is an early test version. It may contain errors, and its features may change or disappear without notice.

## 4. No warranty

The app is provided “as is”, without warranty of any kind. To the extent permitted by law, the author is not liable for any damage or loss resulting from the use of the app.

## 5. Privacy

The app works offline. It does not send any data over the internet and does not need an account.

## 6. Third-party components

The app includes open-source components that remain under their own licenses. Their notices are in the `THIRD-PARTY-NOTICES.txt` file installed with the app, in `/usr/share/doc/strunova/`.

## 7. Changes

These terms may change in future versions of the app. Each version comes with the terms that apply to it.
